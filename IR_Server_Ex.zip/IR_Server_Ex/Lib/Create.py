import sqlite3
import json
import os.path
import pandas as pd


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(BASE_DIR,"sensor.db")
db_path = "/home/pi/Desktop/IR_Server_Ex/SQLiteDB/sensor.db"
print(db_path)
mydb=sqlite3.connect(db_path)
cursor = mydb.cursor()

#sql = f"CREATE TABLE 'sensor_data2' ('sensor_id'	INTEGER PRIMARY KEY AUTOINCREMENT,'sensor_no'	TEXT,'sensor_type'	TEXT,'sensor_value'	TEXT,'input_time'timestamp not null default (datetime('now','localtime')))"
#sql = f"CREATE TABLE 'MacNo' ('_id'	INTEGER PRIMARY KEY AUTOINCREMENT,'mac'	TEXT,'name'	TEXT,'input_time'timestamp not null default (datetime('now','localtime')))"
#sql = f"CREATE TABLE 'MacSpc' ('_id'	INTEGER PRIMARY KEY AUTOINCREMENT,'mac'	TEXT,'parameter' TEXT,'value' TEXT,'input_time'timestamp not null default (datetime('now','localtime')))"
#sql = f"delete from 'sensor_data2'  where Row_number <= (select (count(*)-1400) from 'sensor_data2') "
#
#sql = "SELECT * FROM 'sensor_data2' WHERE  sensor_no + '-' + snesor_id in (SELECT sensor_no + '-' + snesor_id AS id 
#                                                                        FROM (SELECT sensor_no, snesor_id,  
#                                                                              row_number() OVER (partition BY sensor_no ORDER BY sensor_no, snesor_id DESC) AS RANK 
#                                                                              FROM   'sensor_data2') AS TMP 
#                                                                              WHERE RANK > 2) "
#Select FROM 'sensor_data2' WHERE ((SELECT COUNT(sensor_id) AS rank FROM 'sensor_data2' AS temp WHERE (Table1.購買物品 = temp.購買物品) AND (temp.第幾次 > Table1.第幾次)) > 1)
Table = 'sensor_data2'
sql = f"SELECT * from(SELECT * ,ROW_NUMBER() OVER (PARTITION BY sensor_no ORDER BY sensor_id desc) sn from %s)R where (R.sn=1 or R.sn=2) and sensor_type =4"%Table
cursor.execute(sql)
print(cursor)