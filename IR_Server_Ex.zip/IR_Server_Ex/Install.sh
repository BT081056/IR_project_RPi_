sudo -s apt-get update
sudo apt-get install sqlitebrowser
sudo apt-get install sqlite3
sudo apt-get install ifmetric
pip3 install pandas
pip3 install sqlite3