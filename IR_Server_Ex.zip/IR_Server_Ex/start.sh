#!/bin/bash
for var in {10..1};
do
 echo 'System will start in '$var;
 sleep 1
done
sudo ifmetric eth0 500
sudo ifmetric wlan0 500
route -n

python3 /home/pi/Desktop/IR_Server_Ex/web.py