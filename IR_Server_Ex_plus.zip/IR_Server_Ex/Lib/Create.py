import sqlite3
import json
import os.path
import pandas as pd

#sqldb_path = 'sensor.db'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(BASE_DIR,"sensor.db")
db_path = "/home/pi/Desktop/flask_web/SQLiteDB/sensor.db"
print(db_path)
mydb=sqlite3.connect(db_path)
cursor = mydb.cursor()

#sql = f"CREATE TABLE 'sensor_data2' ('sensor_id'	INTEGER PRIMARY KEY AUTOINCREMENT,'sensor_no'	TEXT,'sensor_type'	TEXT,'sensor_value'	TEXT,'input_time'timestamp not null default (datetime('now','localtime')))"
sql = f"CREATE TABLE 'MacNo' ('_id'	INTEGER PRIMARY KEY AUTOINCREMENT,'mac'	TEXT,'name'	TEXT,'input_time'timestamp not null default (datetime('now','localtime')))"
#sql = f"CREATE TABLE 'MacSpc' ('_id'	INTEGER PRIMARY KEY AUTOINCREMENT,'mac'	TEXT,'parameter' TEXT,'value' TEXT,'input_time'timestamp not null default (datetime('now','localtime')))"
cursor.execute(sql)