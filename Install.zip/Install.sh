sudo apt-get install sqlite3
sudo apt-get install ifmetric